﻿using System;

namespace BlackScholesPricingLibrary
{
    public enum OptionType { Call, Put };

    public static class BlackScholesOptionPricer
    {     
        // The Black and Scholes parameters:	
		//	s = Stock price
		//  k = Strike price
		//  t = Years to maturity
		//	r = Risk-free rate
		//  sd = Standard deviation
        //
        // We don't do any parameter value checking here
        // Because we assume it has been done by the calling code		
        public static double ComputeOptionPrice(OptionType optionType, double s, double k, double t, double r, double sd)
        {
            double d1 = 0.0;
            double d2 = 0.0;
            double optionPriceRetVal = 0.0;

            d1 = (Math.Log(s / k) + (r + sd * sd / 2.0) * t) / (sd * Math.Sqrt(t));
            d2 = d1 - sd * Math.Sqrt(t);

            if (optionType == OptionType.Call)
            {
                optionPriceRetVal = s * CumulativeNormalDistribution(d1) - k * Math.Exp(-r * t) * CumulativeNormalDistribution(d2);
            }
            else // We know it's a put then 
            {
                optionPriceRetVal = k * Math.Exp(-r * t) * CumulativeNormalDistribution(-d2) - s * CumulativeNormalDistribution(-d1);
            }

            return Math.Round(optionPriceRetVal, 4, MidpointRounding.ToEven);
        }

         
        // From https://www.johndcook.com/blog/csharp_phi/
        private static double CumulativeNormalDistribution(double x)
        {
            // constants
            double a1 = 0.254829592;
            double a2 = -0.284496736;
            double a3 = 1.421413741;
            double a4 = -1.453152027;
            double a5 = 1.061405429;
            double p = 0.3275911;

            // Save the sign of x
            int sign = 1;
            if (x < 0)
                sign = -1;
            x = Math.Abs(x) / Math.Sqrt(2.0);

            // A&S formula 7.1.26
            double t = 1.0 / (1.0 + p * x);
            double y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.Exp(-x * x);

            return 0.5 * (1.0 + sign * y);
        }
    }
}

