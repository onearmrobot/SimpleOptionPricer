﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BlackScholesPricingLibrary;

namespace OptionPricerUnitTests
{
    [TestClass]
    public class OptionPricerUnitTests
    {
        [TestMethod]
        public void TestCallOptionPricing1()
        {
            double callPrice = BlackScholesOptionPricer.ComputeOptionPrice(OptionType.Call, 50, 55, 1, 0.09, 0.2);

            Assert.AreEqual(3.8617, callPrice);
        }

        [TestMethod]
        public void TestCallOptionPricing2()
        {
            double callPrice = BlackScholesOptionPricer.ComputeOptionPrice(OptionType.Call, 64, 60, 0.493150, 0.045, 0.27);

            Assert.AreEqual(7.7661, callPrice);
        }

        [TestMethod]
        public void TestPutOptionPricing1()
        {
            double putPrice = BlackScholesOptionPricer.ComputeOptionPrice(OptionType.Put, 50, 55, 1, 0.09, 0.2);

            Assert.AreEqual(4.1279, putPrice);
        }

        [TestMethod]
        public void TestPutOptionPricing2()
        {
            double putPrice = BlackScholesOptionPricer.ComputeOptionPrice(OptionType.Put, 64, 60, 0.493150, 0.045, 0.27);

            Assert.AreEqual(2.4493, putPrice);
        }

        [TestMethod]
        public void TestPutOptionPricingWrongMaturity()
        {
            double putPrice = BlackScholesOptionPricer.ComputeOptionPrice(OptionType.Put, 64, 60, -1, 0.045, 0.27);

            Assert.AreEqual(double.NaN, putPrice);
        }
    }
}
