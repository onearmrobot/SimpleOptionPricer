﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using BlackScholesPricingLibrary;


namespace SimpleOptionPricer
{
    struct BlackScholesParams
    {
        public double stockPrice;
        public double strikePrice;
        public double timeToMaturity;
        public double riskFreeIR;
        public double standardDeviation;
    }

    public partial class OptionPricerForm : Form
    {
        public OptionPricerForm()
        {
            InitializeComponent();
        }

        private void buttonGetQuote_Click(object sender, EventArgs e)
        {
            BlackScholesParams bsp;
            if (!TryGetParameters(out bsp) )
            {
                MessageBox.Show("Not all input parameters are valid");
                return;
            }

            ComputeOptionPrices(bsp);
        }

        private void ComputeOptionPrices(BlackScholesParams bsp)
        {
            double callPrice = BlackScholesOptionPricer.ComputeOptionPrice(OptionType.Call, bsp.stockPrice, bsp.strikePrice, bsp.timeToMaturity, bsp.riskFreeIR, bsp.standardDeviation);
            double putPrice  = BlackScholesOptionPricer.ComputeOptionPrice(OptionType.Put, bsp.stockPrice, bsp.strikePrice, bsp.timeToMaturity, bsp.riskFreeIR, bsp.standardDeviation);

            textBoxCallOptionPrice.Text = callPrice.ToString();
            textBoxPutOptionPrice.Text = putPrice.ToString();
        }

        // Need to do validation here because there is no garanty that
        // When the user presses the 'Get Quote' button, all parameters
        // Have been validated via the TextBox 'Validating' event
        private bool TryGetParameters(out BlackScholesParams bsp)
        {
            // Parse and get the parameters values
            bsp = new BlackScholesParams();
            double parsedValue;

            if (!double.TryParse(textBoxStockPrice.Text, out parsedValue))
                return false;

            bsp.stockPrice = parsedValue;

            if (!double.TryParse(textBoxStrikePrice.Text, out parsedValue))
                return false;

            bsp.strikePrice = parsedValue;

            if (!double.TryParse(textBoxTimeToMaturity.Text, out parsedValue) || (parsedValue <= 0))
                return false;

            bsp.timeToMaturity = parsedValue;

            if (!double.TryParse(textBoxRiskFreeIR.Text, out parsedValue))
                return false;

            bsp.riskFreeIR = parsedValue;

            if (!double.TryParse(textBoxStandardDeviation.Text, out parsedValue))
                return false;

            bsp.standardDeviation = parsedValue;

            return true;
        }

        #region Parameter Validation

        private bool IsValidDouble(string stockPriceText, Func<double, bool> extraValidation = null)
        {
            double parsedValue;
            if (!double.TryParse(stockPriceText, out parsedValue))
                    return false;

            return (extraValidation == null) ? true : extraValidation(parsedValue);
        }


        private void ValidateTextBox(TextBox tb, Func<double, bool> customValidation = null, string customErrorMessage = null)
        {
            if (!IsValidDouble(tb.Text, customValidation))
            {
                char decimalSeparator = Convert.ToChar(Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator);

                string errorMessage = string.Format("Only numbers (decimal separator is: '{0}' )", decimalSeparator);

                if (!string.IsNullOrEmpty(customErrorMessage))
                    errorMessage += " " + customErrorMessage;

                errorProvider.SetError(tb, errorMessage);
            }
            else
                errorProvider.SetError(tb, "");
        }

        private void textBoxStockPrice_Validating(object sender, CancelEventArgs e)
        {
            ValidateTextBox(textBoxStockPrice);
        }

        private void textBoxStrikePrice_Validating(object sender, CancelEventArgs e)
        {
            ValidateTextBox(textBoxStrikePrice);
        }

        private void textBoxTimeToMaturity_Validating(object sender, CancelEventArgs e)
        {
            ValidateTextBox(textBoxTimeToMaturity, d => d > 0, "Param > 0 only" );
        }

        private void textBoxStandardDeviation_Validating(object sender, CancelEventArgs e)
        {
            ValidateTextBox(textBoxStandardDeviation);
        }

        private void textBoxRiskFreeIR_Validating(object sender, CancelEventArgs e)
        {
            ValidateTextBox(textBoxRiskFreeIR);
        }

        #endregion

        #region Reset Results On Input Params Changed

        private void textBoxStockPrice_TextChanged(object sender, EventArgs e)
        {
            ClearResults();
        }

        private void textBoxStrikePrice_TextChanged(object sender, EventArgs e)
        {
            ClearResults();
        }

        private void textBoxTimeToMaturity_TextChanged(object sender, EventArgs e)
        {
            ClearResults();
        }

        private void textBoxStandardDeviation_TextChanged(object sender, EventArgs e)
        {
            ClearResults();
        }

        private void textBoxRiskFreeIR_TextChanged(object sender, EventArgs e)
        {
            ClearResults();
        }

        private void ClearResults()
        {
            textBoxCallOptionPrice.Clear();
            textBoxPutOptionPrice.Clear();
        }

        #endregion
    }
}
