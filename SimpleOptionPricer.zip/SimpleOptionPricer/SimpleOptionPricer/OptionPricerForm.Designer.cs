﻿namespace SimpleOptionPricer
{
    partial class OptionPricerForm
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxStockPrice = new System.Windows.Forms.TextBox();
            this.textBoxStrikePrice = new System.Windows.Forms.TextBox();
            this.textBoxTimeToMaturity = new System.Windows.Forms.TextBox();
            this.textBoxStandardDeviation = new System.Windows.Forms.TextBox();
            this.textBoxRiskFreeIR = new System.Windows.Forms.TextBox();
            this.textBoxCallOptionPrice = new System.Windows.Forms.TextBox();
            this.textBoxPutOptionPrice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonGetQuote = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(192, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Stock Price:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(193, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Strike Price:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(193, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Time to Maturity (in years):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(193, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(197, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Standard Deviation of Underlying Stock:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(193, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Risk-free Interest Rate:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(193, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Call Option Price:";
            // 
            // textBoxStockPrice
            // 
            this.textBoxStockPrice.Location = new System.Drawing.Point(406, 70);
            this.textBoxStockPrice.Name = "textBoxStockPrice";
            this.textBoxStockPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxStockPrice.TabIndex = 6;
            this.textBoxStockPrice.TextChanged += new System.EventHandler(this.textBoxStockPrice_TextChanged);
            this.textBoxStockPrice.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStockPrice_Validating);
            // 
            // textBoxStrikePrice
            // 
            this.textBoxStrikePrice.Location = new System.Drawing.Point(406, 90);
            this.textBoxStrikePrice.Name = "textBoxStrikePrice";
            this.textBoxStrikePrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxStrikePrice.TabIndex = 7;
            this.textBoxStrikePrice.TextChanged += new System.EventHandler(this.textBoxStrikePrice_TextChanged);
            this.textBoxStrikePrice.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStrikePrice_Validating);
            // 
            // textBoxTimeToMaturity
            // 
            this.textBoxTimeToMaturity.Location = new System.Drawing.Point(406, 110);
            this.textBoxTimeToMaturity.Name = "textBoxTimeToMaturity";
            this.textBoxTimeToMaturity.Size = new System.Drawing.Size(100, 20);
            this.textBoxTimeToMaturity.TabIndex = 8;
            this.textBoxTimeToMaturity.TextChanged += new System.EventHandler(this.textBoxTimeToMaturity_TextChanged);
            this.textBoxTimeToMaturity.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxTimeToMaturity_Validating);
            // 
            // textBoxStandardDeviation
            // 
            this.textBoxStandardDeviation.Location = new System.Drawing.Point(406, 130);
            this.textBoxStandardDeviation.Name = "textBoxStandardDeviation";
            this.textBoxStandardDeviation.Size = new System.Drawing.Size(100, 20);
            this.textBoxStandardDeviation.TabIndex = 9;
            this.textBoxStandardDeviation.TextChanged += new System.EventHandler(this.textBoxStandardDeviation_TextChanged);
            this.textBoxStandardDeviation.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxStandardDeviation_Validating);
            // 
            // textBoxRiskFreeIR
            // 
            this.textBoxRiskFreeIR.Location = new System.Drawing.Point(406, 150);
            this.textBoxRiskFreeIR.Name = "textBoxRiskFreeIR";
            this.textBoxRiskFreeIR.Size = new System.Drawing.Size(100, 20);
            this.textBoxRiskFreeIR.TabIndex = 10;
            this.textBoxRiskFreeIR.TextChanged += new System.EventHandler(this.textBoxRiskFreeIR_TextChanged);
            this.textBoxRiskFreeIR.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxRiskFreeIR_Validating);
            // 
            // textBoxCallOptionPrice
            // 
            this.textBoxCallOptionPrice.Location = new System.Drawing.Point(406, 199);
            this.textBoxCallOptionPrice.Name = "textBoxCallOptionPrice";
            this.textBoxCallOptionPrice.ReadOnly = true;
            this.textBoxCallOptionPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxCallOptionPrice.TabIndex = 11;
            this.textBoxCallOptionPrice.TabStop = false;
            // 
            // textBoxPutOptionPrice
            // 
            this.textBoxPutOptionPrice.Location = new System.Drawing.Point(406, 218);
            this.textBoxPutOptionPrice.Name = "textBoxPutOptionPrice";
            this.textBoxPutOptionPrice.ReadOnly = true;
            this.textBoxPutOptionPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxPutOptionPrice.TabIndex = 13;
            this.textBoxPutOptionPrice.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(193, 225);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Put Option Price:";
            // 
            // buttonGetQuote
            // 
            this.buttonGetQuote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonGetQuote.Location = new System.Drawing.Point(621, 148);
            this.buttonGetQuote.Name = "buttonGetQuote";
            this.buttonGetQuote.Size = new System.Drawing.Size(75, 23);
            this.buttonGetQuote.TabIndex = 14;
            this.buttonGetQuote.Text = "Get Quote";
            this.buttonGetQuote.UseVisualStyleBackColor = true;
            this.buttonGetQuote.Click += new System.EventHandler(this.buttonGetQuote_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // OptionPricerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 307);
            this.Controls.Add(this.buttonGetQuote);
            this.Controls.Add(this.textBoxPutOptionPrice);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxCallOptionPrice);
            this.Controls.Add(this.textBoxRiskFreeIR);
            this.Controls.Add(this.textBoxStandardDeviation);
            this.Controls.Add(this.textBoxTimeToMaturity);
            this.Controls.Add(this.textBoxStrikePrice);
            this.Controls.Add(this.textBoxStockPrice);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "OptionPricerForm";
            this.Text = "Simple Option Pricer";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxStockPrice;
        private System.Windows.Forms.TextBox textBoxStrikePrice;
        private System.Windows.Forms.TextBox textBoxTimeToMaturity;
        private System.Windows.Forms.TextBox textBoxStandardDeviation;
        private System.Windows.Forms.TextBox textBoxRiskFreeIR;
        private System.Windows.Forms.TextBox textBoxCallOptionPrice;
        private System.Windows.Forms.TextBox textBoxPutOptionPrice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonGetQuote;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}

